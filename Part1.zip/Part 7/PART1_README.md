# Part 1 - Core Structure, Configurations & Main Entry Points

This ZIP contains the foundational parts of the Jarvis Assistant Android project:

- Project root configuration files (Gradle, settings, .gitignore, LICENSE, README, scripts)
- app/build.gradle.kts, proguard-rules.pro
- AndroidManifest.xml
- Main application entry point: JarvisApp.kt
- Core packages:
  - audio/
  - background/
  - data/
  - network/
  - security/
  - util/
- All resources (res/)
- Smaller assets (three.min.js and other non-model assets)

**Note:** Feature modules (automation, vision, ui), large speech model assets (model-en-us, model-spk), overlay toys, HUD/settings HTML, docs, and tests are in Part 2.

To reconstruct the full project, extract both Part1.zip and Part2.zip into the same directory (they share the "Part 7/" root path structure).
