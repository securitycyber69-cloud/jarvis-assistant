# Part 2A - Feature Modules

Contains automation, vision, ui packages, overlay assets, docs, tests.

Combine with Part1 + Part2B1-4 + Part2C to get full project.
