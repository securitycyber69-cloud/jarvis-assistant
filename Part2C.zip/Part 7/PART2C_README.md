# Part 2C - Speaker Model (model-spk)

Extract with others to reconstruct full project.
